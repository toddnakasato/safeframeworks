
  # Organism Designer

  This is a code bundle for Organism Designer. The original project is available at https://www.figma.com/design/oOjHNvqtwPZRvMIS3ZzCng/Organism-Designer.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  