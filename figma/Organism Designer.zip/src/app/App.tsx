import { useState } from "react";
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { ComponentPalette } from "./components/ComponentPalette";
import { DesignSurface } from "./components/DesignSurface";
import { AIAssistantChat } from "./components/AIAssistantChat";
import { OrganismLayout } from "./components/OrganismDesigner";
import {
  ChainComponent,
  ComponentTemplate,
  StructuralSection,
  ChainMethod,
} from "./types/fluent-chain";
import { Button } from "./components/ui/button";
import { Trash2, FileCode } from "lucide-react";

export default function App() {
  const [selectedLayout, setSelectedLayout] = useState<OrganismLayout | null>(null);
  const [components, setComponents] = useState<Record<StructuralSection, ChainComponent[]>>({
    topRow: [],
    mainBody: [],
    leftPanel: [],
    rightPanel: [],
    bottomRow: [],
  });

  const generateId = () => {
    return `comp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  };

  const createComponentFromTemplate = (
    template: ComponentTemplate,
    structuralSection?: StructuralSection,
  ): ChainComponent => {
    return {
      id: generateId(),
      type: template.type,
      name: template.name,
      methods: [],
      children: [],
      structuralSection,
    };
  };

  const handleAddComponent = (template: ComponentTemplate) => {
    // Not used in new drag-drop design
  };

  const handleAddOrganismLayout = (layout: OrganismLayout) => {
    setSelectedLayout(layout);
    // Clear components when selecting new layout
    setComponents({
      topRow: [],
      mainBody: [],
      leftPanel: [],
      rightPanel: [],
      bottomRow: [],
    });
  };

  const handleDropComponent = (section: StructuralSection, template: ComponentTemplate) => {
    const newComponent = createComponentFromTemplate(template, section);
    setComponents(prev => ({
      ...prev,
      [section]: [...prev[section], newComponent],
    }));
  };

  const handleRemoveComponent = (section: StructuralSection, componentId: string) => {
    setComponents(prev => ({
      ...prev,
      [section]: prev[section].filter(c => c.id !== componentId),
    }));
  };

  const handleUpdateMethod = (
    componentId: string,
    methodId: string,
    value: string | boolean,
  ) => {
    setComponents(prev => {
      const updated = { ...prev };
      for (const section of Object.keys(updated) as StructuralSection[]) {
        updated[section] = updated[section].map(comp => {
          if (comp.id === componentId) {
            return {
              ...comp,
              methods: comp.methods.map(method =>
                method.id === methodId ? { ...method, value } : method
              ),
            };
          }
          return comp;
        });
      }
      return updated;
    });
  };

  const handleAddMethod = (
    componentId: string,
    methodName: string,
  ) => {
    const newMethod: ChainMethod = {
      id: generateId(),
      name: methodName,
      type: "config",
      value: "",
    };

    setComponents(prev => {
      const updated = { ...prev };
      for (const section of Object.keys(updated) as StructuralSection[]) {
        updated[section] = updated[section].map(comp => {
          if (comp.id === componentId) {
            return {
              ...comp,
              methods: [...comp.methods, newMethod],
            };
          }
          return comp;
        });
      }
      return updated;
    });
  };

  const handleRemoveMethod = (
    componentId: string,
    methodId: string,
  ) => {
    setComponents(prev => {
      const updated = { ...prev };
      for (const section of Object.keys(updated) as StructuralSection[]) {
        updated[section] = updated[section].map(comp => {
          if (comp.id === componentId) {
            return {
              ...comp,
              methods: comp.methods.filter(method => method.id !== methodId),
            };
          }
          return comp;
        });
      }
      return updated;
    });
  };

  const handleClearAll = () => {
    if (
      confirm(
        "Are you sure you want to clear all components? This cannot be undone.",
      )
    ) {
      setSelectedLayout(null);
      setComponents({
        topRow: [],
        mainBody: [],
        leftPanel: [],
        rightPanel: [],
        bottomRow: [],
      });
    }
  };

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="size-full flex flex-col bg-background">
        {/* Header */}
        <header className="border-b border-border bg-card px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <FileCode className="h-6 w-6 text-primary" />
              <div>
                <h1 className="m-0">Organism Designer</h1>
                <p className="text-muted-foreground text-sm m-0">
                  Drag and drop visual editor for creating organisms
                </p>
              </div>
            </div>
            {selectedLayout && (
              <Button
                variant="destructive"
                size="sm"
                onClick={handleClearAll}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Clear All
              </Button>
            )}
          </div>
        </header>

        {/* Main Content */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Panel - Component Palette */}
          <div className="w-80 flex-shrink-0">
            <ComponentPalette
              onAddComponent={handleAddComponent}
              onAddOrganismLayout={handleAddOrganismLayout}
            />
          </div>

          {/* Center Panel - Design Surface */}
          <div className="flex-1 min-w-0">
            <DesignSurface
              layout={selectedLayout}
              components={components}
              onDropComponent={handleDropComponent}
              onRemoveComponent={handleRemoveComponent}
              onUpdateMethod={handleUpdateMethod}
              onAddMethod={handleAddMethod}
              onRemoveMethod={handleRemoveMethod}
            />
          </div>

          {/* Right Panel - AI Assistant Chat */}
          <div className="w-96 flex-shrink-0">
            <AIAssistantChat />
          </div>
        </div>
      </div>
    </DndProvider>
  );
}