import { ComponentTemplate } from '../types/fluent-chain';

export interface OrganismLayout {
  name: string;
  description: string;
  sections: string[];
  category: 'single' | 'two' | 'three' | 'four' | 'five';
  icon: (props: React.SVGProps<SVGSVGElement>) => JSX.Element;
}

// Layout Icons
const MainOnlyIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none" {...props}>
    <rect x="4" y="4" width="24" height="24" rx="2" fill="currentColor" fillOpacity="0.8" />
  </svg>
);

const TopMainIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none" {...props}>
    <rect x="4" y="4" width="24" height="6" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="4" y="12" width="24" height="16" rx="2" fill="currentColor" fillOpacity="0.8" />
  </svg>
);

const LeftMainIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none" {...props}>
    <rect x="4" y="4" width="8" height="24" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="14" y="4" width="14" height="24" rx="2" fill="currentColor" fillOpacity="0.8" />
  </svg>
);

const MainRightIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none" {...props}>
    <rect x="4" y="4" width="14" height="24" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="20" y="4" width="8" height="24" rx="2" fill="currentColor" fillOpacity="0.8" />
  </svg>
);

const MainBottomIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none" {...props}>
    <rect x="4" y="4" width="24" height="16" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="4" y="22" width="24" height="6" rx="2" fill="currentColor" fillOpacity="0.8" />
  </svg>
);

const TopMainRightIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none" {...props}>
    <rect x="4" y="4" width="24" height="5" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="4" y="11" width="15" height="17" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="21" y="11" width="7" height="17" rx="2" fill="currentColor" fillOpacity="0.8" />
  </svg>
);

const TopLeftMainIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none" {...props}>
    <rect x="4" y="4" width="24" height="5" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="4" y="11" width="7" height="17" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="13" y="11" width="15" height="17" rx="2" fill="currentColor" fillOpacity="0.8" />
  </svg>
);

const LeftMainRightIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none" {...props}>
    <rect x="4" y="4" width="6" height="24" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="12" y="4" width="10" height="24" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="24" y="4" width="4" height="24" rx="2" fill="currentColor" fillOpacity="0.8" />
  </svg>
);

const TopMainBottomIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none" {...props}>
    <rect x="4" y="4" width="24" height="5" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="4" y="11" width="24" height="12" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="4" y="25" width="24" height="3" rx="2" fill="currentColor" fillOpacity="0.8" />
  </svg>
);

const TopLeftMainRightIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none" {...props}>
    <rect x="4" y="4" width="24" height="5" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="4" y="11" width="6" height="17" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="12" y="11" width="10" height="17" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="24" y="11" width="4" height="17" rx="2" fill="currentColor" fillOpacity="0.8" />
  </svg>
);

const TopLeftMainBottomIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none" {...props}>
    <rect x="4" y="4" width="24" height="5" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="4" y="11" width="6" height="14" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="12" y="11" width="16" height="14" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="4" y="27" width="24" height="1" rx="0.5" fill="currentColor" fillOpacity="0.8" />
  </svg>
);

const TopMainRightBottomIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none" {...props}>
    <rect x="4" y="4" width="24" height="5" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="4" y="11" width="16" height="14" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="22" y="11" width="6" height="14" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="4" y="27" width="24" height="1" rx="0.5" fill="currentColor" fillOpacity="0.8" />
  </svg>
);

const CompleteLayoutIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none" {...props}>
    <rect x="4" y="4" width="24" height="4" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="4" y="10" width="6" height="18" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="12" y="10" width="10" height="15" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="24" y="10" width="4" height="18" rx="2" fill="currentColor" fillOpacity="0.8" />
    <rect x="12" y="27" width="10" height="1" rx="0.5" fill="currentColor" fillOpacity="0.8" />
  </svg>
);

export const ORGANISM_LAYOUTS: OrganismLayout[] = [
  // Single Panel
  {
    name: 'Main Only',
    description: 'Single main content area',
    sections: ['mainBody'],
    category: 'single',
    icon: MainOnlyIcon,
  },
  
  // Two Panel
  {
    name: 'Top + Main',
    description: 'Header with main content',
    sections: ['topRow', 'mainBody'],
    category: 'two',
    icon: TopMainIcon,
  },
  {
    name: 'Left + Main',
    description: 'Sidebar with main content',
    sections: ['leftPanel', 'mainBody'],
    category: 'two',
    icon: LeftMainIcon,
  },
  {
    name: 'Main + Right',
    description: 'Main content with right sidebar',
    sections: ['mainBody', 'rightPanel'],
    category: 'two',
    icon: MainRightIcon,
  },
  {
    name: 'Main + Bottom',
    description: 'Main content with footer',
    sections: ['mainBody', 'bottomRow'],
    category: 'two',
    icon: MainBottomIcon,
  },
  
  // Three Panel
  {
    name: 'Top + Main + Right',
    description: 'Header, main, and right sidebar',
    sections: ['topRow', 'mainBody', 'rightPanel'],
    category: 'three',
    icon: TopMainRightIcon,
  },
  {
    name: 'Top + Left + Main',
    description: 'Header, left sidebar, and main',
    sections: ['topRow', 'leftPanel', 'mainBody'],
    category: 'three',
    icon: TopLeftMainIcon,
  },
  {
    name: 'Left + Main + Right',
    description: 'Three column layout',
    sections: ['leftPanel', 'mainBody', 'rightPanel'],
    category: 'three',
    icon: LeftMainRightIcon,
  },
  {
    name: 'Top + Main + Bottom',
    description: 'Header, main, and footer',
    sections: ['topRow', 'mainBody', 'bottomRow'],
    category: 'three',
    icon: TopMainBottomIcon,
  },
  
  // Four Panel
  {
    name: 'Top + Left + Main + Right',
    description: 'Header with three columns',
    sections: ['topRow', 'leftPanel', 'mainBody', 'rightPanel'],
    category: 'four',
    icon: TopLeftMainRightIcon,
  },
  {
    name: 'Top + Left + Main + Bottom',
    description: 'Header, sidebar, main, and footer',
    sections: ['topRow', 'leftPanel', 'mainBody', 'bottomRow'],
    category: 'four',
    icon: TopLeftMainBottomIcon,
  },
  {
    name: 'Top + Main + Right + Bottom',
    description: 'Header, main, sidebar, and footer',
    sections: ['topRow', 'mainBody', 'rightPanel', 'bottomRow'],
    category: 'four',
    icon: TopMainRightBottomIcon,
  },
  
  // Five Panel
  {
    name: 'Complete Layout',
    description: 'All sections: top, left, main, right, bottom',
    sections: ['topRow', 'leftPanel', 'mainBody', 'rightPanel', 'bottomRow'],
    category: 'five',
    icon: CompleteLayoutIcon,
  },
];
