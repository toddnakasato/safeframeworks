import { useState } from 'react';
import { ComponentTemplate, ORGANISMS, MOLECULES, ATOMS } from '../types/fluent-chain';
import { ORGANISM_LAYOUTS, OrganismLayout } from './OrganismDesigner';
import { DraggableComponent } from './DraggableComponent';
import { Button } from './ui/button';
import { ScrollArea } from './ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Box, Layers, Atom } from 'lucide-react';

interface ComponentPaletteProps {
  onAddComponent: (template: ComponentTemplate) => void;
  onAddOrganismLayout: (layout: OrganismLayout) => void;
}

export function ComponentPalette({ onAddComponent, onAddOrganismLayout }: ComponentPaletteProps) {
  const [activeTab, setActiveTab] = useState<string>('organisms');

  const renderOrganismLayouts = () => {
    const categories = ['single', 'two', 'three', 'four', 'five'] as const;
    const categoryLabels = {
      single: 'Single Panel',
      two: 'Two Panel',
      three: 'Three Panel',
      four: 'Four Panel',
      five: 'Five Panel',
    };

    return (
      <div className="space-y-4">
        {categories.map(category => {
          const layouts = ORGANISM_LAYOUTS.filter(l => l.category === category);
          if (layouts.length === 0) return null;

          return (
            <div key={category}>
              <h3 className="mb-2 px-2 text-muted-foreground">{categoryLabels[category]}</h3>
              <div className="space-y-1">
                {layouts.map(layout => (
                  <div
                    key={layout.name}
                    className="group rounded-lg border border-border bg-card p-3 hover:bg-accent/50 cursor-pointer transition-colors"
                    onClick={() => onAddOrganismLayout(layout)}
                  >
                    <div className="flex items-start gap-3">
                      <div className="flex-shrink-0 mt-0.5 text-foreground">
                        <layout.icon />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span>{layout.name}</span>
                          <Badge variant="secondary" className="text-xs">
                            organism
                          </Badge>
                        </div>
                        <p className="text-muted-foreground mt-1 text-sm">
                          {layout.description}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  const renderComponentList = (components: ComponentTemplate[]) => {
    const categories = Array.from(new Set(components.map(c => c.category)));
    
    return (
      <div className="space-y-4">
        {categories.map(category => (
          <div key={category}>
            <h3 className="mb-2 px-2 text-muted-foreground">{category}</h3>
            <div className="space-y-1">
              {components
                .filter(c => c.category === category)
                .map(component => (
                  <DraggableComponent key={component.name} template={component}>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span>{component.name}</span>
                          <Badge variant="secondary" className="text-xs">
                            {component.type}
                          </Badge>
                        </div>
                        <p className="text-muted-foreground mt-1 text-sm">
                          {component.description}
                        </p>
                      </div>
                    </div>
                  </DraggableComponent>
                ))}
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="h-full flex flex-col border-r border-border bg-card">
      <div className="p-4 border-b border-border">
        <h2>Component Library</h2>
        <p className="text-muted-foreground text-sm mt-1">
          Click to add components to your chain
        </p>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <TabsList className="w-full justify-start rounded-none border-b border-border bg-transparent p-0">
          <TabsTrigger 
            value="organisms" 
            className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent"
          >
            <Box className="mr-2 h-4 w-4" />
            Organisms
          </TabsTrigger>
          <TabsTrigger 
            value="molecules"
            className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent"
          >
            <Layers className="mr-2 h-4 w-4" />
            Molecules
          </TabsTrigger>
          <TabsTrigger 
            value="atoms"
            className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent"
          >
            <Atom className="mr-2 h-4 w-4" />
            Atoms
          </TabsTrigger>
        </TabsList>
        
        <ScrollArea className="flex-1">
          <div className="p-4">
            <TabsContent value="organisms" className="mt-0">
              {renderOrganismLayouts()}
            </TabsContent>
            <TabsContent value="molecules" className="mt-0">
              {renderComponentList(MOLECULES)}
            </TabsContent>
            <TabsContent value="atoms" className="mt-0">
              {renderComponentList(ATOMS)}
            </TabsContent>
          </div>
        </ScrollArea>
      </Tabs>
    </div>
  );
}
