import { ChainComponent, ComponentTemplate, ORGANISMS, MOLECULES, ATOMS } from '../types/fluent-chain';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { ScrollArea } from './ui/scroll-area';
import { Switch } from './ui/switch';
import { Plus, X } from 'lucide-react';
import { Badge } from './ui/badge';

interface PropertyPanelProps {
  selectedComponent: ChainComponent | null;
  onUpdateMethod: (componentId: string, methodId: string, value: string | boolean) => void;
  onAddMethod: (componentId: string, methodName: string) => void;
  onRemoveMethod: (componentId: string, methodId: string) => void;
}

export function PropertyPanel({
  selectedComponent,
  onUpdateMethod,
  onAddMethod,
  onRemoveMethod,
}: PropertyPanelProps) {
  if (!selectedComponent) {
    return (
      <div className="h-full flex flex-col border-l border-border bg-card">
        <div className="p-4 border-b border-border">
          <h2>Properties</h2>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <p className="text-muted-foreground text-center max-w-xs">
            Select a component from the canvas to edit its properties
          </p>
        </div>
      </div>
    );
  }

  // Find the template for this component
  const allTemplates = [...ORGANISMS, ...MOLECULES, ...ATOMS];
  const template = allTemplates.find(t => t.name === selectedComponent.name);
  
  if (!template) {
    return (
      <div className="h-full flex flex-col border-l border-border bg-card">
        <div className="p-4 border-b border-border">
          <h2>Properties</h2>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <p className="text-muted-foreground">Component template not found</p>
        </div>
      </div>
    );
  }

  const getComponentColor = (type: string) => {
    switch (type) {
      case 'organism':
        return 'bg-blue-500/10 text-blue-500 border-blue-500/20';
      case 'molecule':
        return 'bg-purple-500/10 text-purple-500 border-purple-500/20';
      case 'atom':
        return 'bg-green-500/10 text-green-500 border-green-500/20';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="h-full flex flex-col border-l border-border bg-card">
      <div className="p-4 border-b border-border">
        <h2>Properties</h2>
        <div className="flex items-center gap-2 mt-2">
          <span className="text-sm truncate">{selectedComponent.name}</span>
          <Badge variant="outline" className={`${getComponentColor(selectedComponent.type)} text-xs flex-shrink-0`}>
            {selectedComponent.type}
          </Badge>
        </div>
      </div>
      
      <ScrollArea className="flex-1">
        <div className="p-4 space-y-6">
          {/* Active Methods */}
          {selectedComponent.methods.length > 0 && (
            <div>
              <h3 className="mb-3">Active Methods</h3>
              <div className="space-y-3">
                {selectedComponent.methods.map(method => {
                  const methodTemplate = template.availableMethods.find(m => m.name === method.name);
                  
                  return (
                    <div key={method.id} className="rounded-lg border border-border p-3 bg-background">
                      <div className="flex items-center justify-between mb-2">
                        <Label className="text-sm">
                          .{method.name}()
                        </Label>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => onRemoveMethod(selectedComponent.id, method.id)}
                          className="h-6 w-6 p-0 text-destructive hover:text-destructive"
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                      
                      {methodTemplate?.valueType === 'string' && (
                        <Input
                          value={method.value as string || ''}
                          onChange={(e) => onUpdateMethod(selectedComponent.id, method.id, e.target.value)}
                          placeholder={methodTemplate.placeholder || 'Enter value'}
                          className="text-sm"
                        />
                      )}
                      
                      {methodTemplate?.valueType === 'number' && (
                        <Input
                          type="number"
                          value={method.value as number || ''}
                          onChange={(e) => onUpdateMethod(selectedComponent.id, method.id, e.target.value)}
                          placeholder={methodTemplate.placeholder || '0'}
                          className="text-sm"
                        />
                      )}
                      
                      {methodTemplate?.valueType === 'boolean' && (
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={method.value as boolean || false}
                            onCheckedChange={(checked) => onUpdateMethod(selectedComponent.id, method.id, checked)}
                          />
                          <span className="text-sm text-muted-foreground">
                            {method.value ? 'Enabled' : 'Disabled'}
                          </span>
                        </div>
                      )}
                      
                      {methodTemplate?.valueType === 'none' && (
                        <p className="text-sm text-muted-foreground">No configuration needed</p>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
          
          {/* Available Methods */}
          <div>
            <h3 className="mb-3">Available Methods</h3>
            <div className="space-y-2">
              {template.availableMethods
                .filter(methodTemplate => 
                  !selectedComponent.methods.some(m => m.name === methodTemplate.name)
                )
                .map(methodTemplate => (
                  <Button
                    key={methodTemplate.name}
                    variant="outline"
                    size="sm"
                    onClick={() => onAddMethod(selectedComponent.id, methodTemplate.name)}
                    className="w-full justify-start"
                  >
                    <Plus className="h-3 w-3 mr-2" />
                    .{methodTemplate.name}()
                    <Badge variant="secondary" className="ml-auto text-xs">
                      {methodTemplate.type}
                    </Badge>
                  </Button>
                ))}
              
              {template.availableMethods.length === selectedComponent.methods.length && (
                <p className="text-sm text-muted-foreground text-center py-4">
                  All methods added
                </p>
              )}
            </div>
          </div>
          
          {/* Component Info */}
          <div className="pt-4 border-t border-border">
            <h3 className="mb-2">Component Info</h3>
            <p className="text-sm text-muted-foreground">
              {template.description}
            </p>
            <div className="mt-3 space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Category:</span>
                <span>{template.category}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Can have children:</span>
                <span>{template.canHaveChildren ? 'Yes' : 'No'}</span>
              </div>
              {template.structuralSections && (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Sections:</span>
                  <span>{template.structuralSections.length}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </ScrollArea>
    </div>
  );
}
