import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { Tabs, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import {
  Send,
  Sparkles,
  Layout,
  Lightbulb,
  BookOpen,
  Palette,
  CheckCircle,
  Zap,
  Code2,
  Download,
  FileText,
  ChevronRight,
  Plus,
} from 'lucide-react';

interface Message {
  id: string;
  role: 'assistant' | 'user';
  content: string;
  timestamp: string;
}

const quickActions = [
  {
    icon: Layout,
    title: 'Suggest Layout Patterns',
    description: 'Get layout recommendations',
  },
  {
    icon: Lightbulb,
    title: 'Component Ideas',
    description: 'Generate component suggestions',
  },
  {
    icon: BookOpen,
    title: 'Design Best Practices',
    description: 'Learn fluent chain patterns',
  },
  {
    icon: Palette,
    title: 'Style Suggestions',
    description: 'Improve visual design',
  },
  {
    icon: CheckCircle,
    title: 'Accessibility Check',
    description: 'Review accessibility standards',
  },
  {
    icon: Zap,
    title: 'Performance Tips',
    description: 'Optimize chain performance',
  },
  {
    icon: Code2,
    title: 'Code Optimization',
    description: 'Refactor and improve code',
  },
  {
    icon: Download,
    title: 'Export Options',
    description: 'Save and export your work',
  },
  {
    icon: FileText,
    title: 'Design Templates',
    description: 'Browse starter templates',
  },
  {
    icon: BookOpen,
    title: 'Component Docs',
    description: 'View component documentation',
  },
];

export function AIAssistantChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Hello! I'm your AI design assistant. How can I help you today?",
      timestamp: '07:51 AM',
    },
    {
      id: '2',
      role: 'assistant',
      content: 'You can ask me about components, design patterns, or use the quick actions below.',
      timestamp: '07:51 AM',
    },
  ]);
  const [inputValue, setInputValue] = useState('');

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date().toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
      }),
    };

    setMessages([...messages, newMessage]);
    setInputValue('');

    // Simulate assistant response
    setTimeout(() => {
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: "I'm here to help! What specific aspect of your fluent chain design would you like assistance with?",
        timestamp: new Date().toLocaleTimeString('en-US', {
          hour: '2-digit',
          minute: '2-digit',
        }),
      };
      setMessages((prev) => [...prev, assistantMessage]);
    }, 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="h-full flex flex-col bg-card border-l border-border">
      {/* Header */}
      <div className="border-b border-border p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            <h3 className="m-0">AI Design Assistant</h3>
          </div>
          <Button size="sm" variant="ghost">
            <Plus className="h-4 w-4 mr-2" />
            Create New Assistant
          </Button>
        </div>
        
        <Tabs defaultValue="conversation" className="w-full">
          <TabsList className="w-full">
            <TabsTrigger value="conversation" className="flex-1">
              Conversation
            </TabsTrigger>
            <TabsTrigger value="assistants" className="flex-1">
              My Assistants
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-lg p-3 ${
                  message.role === 'user'
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted'
                }`}
              >
                <p className="text-sm m-0">{message.content}</p>
                <p className="text-xs mt-1 opacity-70">{message.timestamp}</p>
              </div>
            </div>
          ))}

          {/* Quick Action Buttons */}
          {messages.length === 2 && (
            <div className="flex gap-2 flex-wrap pt-2">
              <Badge variant="outline" className="cursor-pointer hover:bg-accent">
                <Sparkles className="h-3 w-3 mr-1" />
                Get Started
              </Badge>
              <Badge variant="outline" className="cursor-pointer hover:bg-accent">
                <BookOpen className="h-3 w-3 mr-1" />
                Explore Features
              </Badge>
              <Badge variant="outline" className="cursor-pointer hover:bg-accent">
                <FileText className="h-3 w-3 mr-1" />
                Help Docs
              </Badge>
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Input Field - Above Quick Actions */}
      <div className="border-t border-border p-4">
        <div className="relative">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Ask about components, patterns..."
            className="pr-12"
          />
          <Button
            size="sm"
            onClick={handleSend}
            className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 p-0"
            disabled={!inputValue.trim()}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Quick Actions List */}
      <div className="border-t border-border">
        <ScrollArea className="max-h-[320px]">
          <div className="p-3 space-y-1">
            {quickActions.map((action, index) => (
              <button
                key={index}
                className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-accent transition-colors text-left group"
              >
                <div className="p-2 rounded-lg bg-muted group-hover:bg-muted-foreground/10">
                  <action.icon className="h-4 w-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm m-0">{action.title}</p>
                  <p className="text-xs text-muted-foreground m-0">
                    {action.description}
                  </p>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-foreground" />
              </button>
            ))}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
