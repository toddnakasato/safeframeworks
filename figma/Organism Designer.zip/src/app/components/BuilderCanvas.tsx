import { ChainComponent, StructuralSection } from '../types/fluent-chain';
import { ChevronRight, ChevronDown, Trash2, Plus } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { useState } from 'react';
import { ScrollArea } from './ui/scroll-area';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';

interface BuilderCanvasProps {
  rootComponent: ChainComponent | null;
  selectedComponentId: string | null;
  onSelectComponent: (id: string | null) => void;
  onDeleteComponent: (id: string) => void;
  onAddChildPrompt: (parentId: string, section?: StructuralSection) => void;
  onUpdateComponentSection: (id: string, section: StructuralSection) => void;
}

export function BuilderCanvas({
  rootComponent,
  selectedComponentId,
  onSelectComponent,
  onDeleteComponent,
  onAddChildPrompt,
  onUpdateComponentSection,
}: BuilderCanvasProps) {
  if (!rootComponent) {
    return (
      <div className="h-full flex items-center justify-center bg-muted/20">
        <div className="text-center max-w-md">
          <h3 className="mb-2">No Component Selected</h3>
          <p className="text-muted-foreground">
            Start by selecting an organism from the Component Library on the left
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-background">
      <div className="p-4 border-b border-border">
        <h2>Builder Canvas</h2>
        <p className="text-muted-foreground text-sm mt-1">
          Click components to edit, build your chain structure
        </p>
      </div>
      
      <ScrollArea className="flex-1">
        <div className="p-4">
          <ComponentNode
            component={rootComponent}
            depth={0}
            selectedId={selectedComponentId}
            onSelect={onSelectComponent}
            onDelete={onDeleteComponent}
            onAddChild={onAddChildPrompt}
            onUpdateSection={onUpdateComponentSection}
          />
        </div>
      </ScrollArea>
    </div>
  );
}

interface ComponentNodeProps {
  component: ChainComponent;
  depth: number;
  selectedId: string | null;
  onSelect: (id: string) => void;
  onDelete: (id: string) => void;
  onAddChild: (parentId: string, section?: StructuralSection) => void;
  onUpdateSection: (id: string, section: StructuralSection) => void;
  parentSection?: StructuralSection;
}

function ComponentNode({
  component,
  depth,
  selectedId,
  onSelect,
  onDelete,
  onAddChild,
  onUpdateSection,
  parentSection,
}: ComponentNodeProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const isSelected = component.id === selectedId;
  const hasChildren = component.children.length > 0;
  
  const getComponentColor = (type: string) => {
    switch (type) {
      case 'organism':
        return 'bg-blue-500/10 text-blue-500 border-blue-500/20';
      case 'molecule':
        return 'bg-purple-500/10 text-purple-500 border-purple-500/20';
      case 'atom':
        return 'bg-green-500/10 text-green-500 border-green-500/20';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  // Group children by structural section if organism
  const childrenBySection: Record<string, ChainComponent[]> = {};
  if (component.type === 'organism') {
    component.children.forEach(child => {
      const section = child.structuralSection || 'mainBody';
      if (!childrenBySection[section]) {
        childrenBySection[section] = [];
      }
      childrenBySection[section].push(child);
    });
  }

  return (
    <div className={`${depth > 0 ? 'ml-6 border-l-2 border-border pl-4' : ''}`}>
      <div
        className={`
          group rounded-lg border p-3 mb-2 cursor-pointer transition-all
          ${isSelected ? 'border-primary bg-primary/5 ring-2 ring-primary/20' : 'border-border bg-card hover:bg-accent/50'}
        `}
        onClick={(e) => {
          e.stopPropagation();
          onSelect(component.id);
        }}
      >
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-start gap-2 flex-1 min-w-0">
            {hasChildren && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setIsExpanded(!isExpanded);
                }}
                className="mt-0.5 text-muted-foreground hover:text-foreground transition-colors flex-shrink-0"
              >
                {isExpanded ? (
                  <ChevronDown className="h-4 w-4" />
                ) : (
                  <ChevronRight className="h-4 w-4" />
                )}
              </button>
            )}
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="truncate">{component.name}</span>
                <Badge variant="outline" className={`${getComponentColor(component.type)} text-xs`}>
                  {component.type}
                </Badge>
                {component.structuralSection && (
                  <Badge variant="outline" className="text-xs">
                    {component.structuralSection}
                  </Badge>
                )}
              </div>
              
              {component.methods.length > 0 && (
                <div className="mt-1 text-sm text-muted-foreground flex flex-wrap gap-1">
                  {component.methods.map(method => (
                    <span key={method.id} className="inline-flex items-center">
                      .{method.name}
                      {method.value && `('${method.value}')`}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>
          
          <div className="flex items-center gap-1 flex-shrink-0">
            {component.type !== 'atom' && (
              <Button
                size="sm"
                variant="ghost"
                onClick={(e) => {
                  e.stopPropagation();
                  onAddChild(component.id);
                }}
                className="h-7 w-7 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Plus className="h-3 w-3" />
              </Button>
            )}
            {depth > 0 && (
              <Button
                size="sm"
                variant="ghost"
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(component.id);
                }}
                className="h-7 w-7 p-0 opacity-0 group-hover:opacity-100 transition-opacity text-destructive hover:text-destructive"
              >
                <Trash2 className="h-3 w-3" />
              </Button>
            )}
          </div>
        </div>
        
        {component.type === 'organism' && isSelected && (
          <div className="mt-3 pt-3 border-t border-border">
            <p className="text-sm text-muted-foreground mb-2">Add to section:</p>
            <div className="flex gap-2 flex-wrap">
              {component.children.length === 0 ? (
                <>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={(e) => {
                      e.stopPropagation();
                      onAddChild(component.id, 'topRow');
                    }}
                  >
                    <Plus className="h-3 w-3 mr-1" />
                    topRow()
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={(e) => {
                      e.stopPropagation();
                      onAddChild(component.id, 'mainBody');
                    }}
                  >
                    <Plus className="h-3 w-3 mr-1" />
                    mainBody()
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={(e) => {
                      e.stopPropagation();
                      onAddChild(component.id, 'rightPanel');
                    }}
                  >
                    <Plus className="h-3 w-3 mr-1" />
                    rightPanel()
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={(e) => {
                      e.stopPropagation();
                      onAddChild(component.id, 'bottomRow');
                    }}
                  >
                    <Plus className="h-3 w-3 mr-1" />
                    bottomRow()
                  </Button>
                </>
              ) : (
                <p className="text-sm text-muted-foreground">
                  Add molecules to sections below
                </p>
              )}
            </div>
          </div>
        )}
      </div>
      
      {isExpanded && component.type === 'organism' && Object.keys(childrenBySection).length > 0 && (
        <div className="ml-4 space-y-2">
          {Object.entries(childrenBySection).map(([section, children]) => (
            <div key={section}>
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="secondary" className="text-xs">
                  .{section}()
                </Badge>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={(e) => {
                    e.stopPropagation();
                    onAddChild(component.id, section as StructuralSection);
                  }}
                  className="h-6 px-2 text-xs"
                >
                  <Plus className="h-3 w-3 mr-1" />
                  Add molecule
                </Button>
              </div>
              {children.map(child => (
                <ComponentNode
                  key={child.id}
                  component={child}
                  depth={depth + 1}
                  selectedId={selectedId}
                  onSelect={onSelect}
                  onDelete={onDelete}
                  onAddChild={onAddChild}
                  onUpdateSection={onUpdateSection}
                  parentSection={section as StructuralSection}
                />
              ))}
            </div>
          ))}
        </div>
      )}
      
      {isExpanded && component.type !== 'organism' && hasChildren && (
        <div className="space-y-1">
          {component.children.map(child => (
            <ComponentNode
              key={child.id}
              component={child}
              depth={depth + 1}
              selectedId={selectedId}
              onSelect={onSelect}
              onDelete={onDelete}
              onAddChild={onAddChild}
              onUpdateSection={onUpdateSection}
            />
          ))}
        </div>
      )}
    </div>
  );
}
