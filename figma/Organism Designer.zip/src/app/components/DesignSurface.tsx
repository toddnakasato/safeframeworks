import { useState } from 'react';
import { ChainComponent, StructuralSection, ComponentTemplate, ORGANISMS, MOLECULES, ATOMS } from '../types/fluent-chain';
import { OrganismLayout } from './OrganismDesigner';
import { VisualDesignCanvas } from './VisualDesignCanvas';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Code, X, Eye } from 'lucide-react';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from './ui/sheet';
import { generateFluentChainCode } from '../utils/code-generator';
import { ScrollArea } from './ui/scroll-area';
import { LivePreview } from './LivePreview';

interface DesignSurfaceProps {
  layout: OrganismLayout | null;
  components: Record<StructuralSection, ChainComponent[]>;
  onDropComponent: (section: StructuralSection, template: ComponentTemplate) => void;
  onRemoveComponent: (section: StructuralSection, componentId: string) => void;
  onUpdateMethod: (componentId: string, methodId: string, value: string | boolean) => void;
  onAddMethod: (componentId: string, methodName: string) => void;
  onRemoveMethod: (componentId: string, methodId: string) => void;
}

export function DesignSurface({
  layout,
  components,
  onDropComponent,
  onRemoveComponent,
  onUpdateMethod,
  onAddMethod,
  onRemoveMethod,
}: DesignSurfaceProps) {
  const [selectedComponentId, setSelectedComponentId] = useState<string | null>(null);
  const [propertiesOpen, setPropertiesOpen] = useState(false);
  const [codeOpen, setCodeOpen] = useState(false);

  const findSelectedComponent = (): ChainComponent | null => {
    if (!selectedComponentId) return null;
    
    for (const section of Object.keys(components) as StructuralSection[]) {
      const found = components[section]?.find(c => c.id === selectedComponentId);
      if (found) return found;
    }
    return null;
  };

  const selectedComponent = findSelectedComponent();

  // Generate code from current state
  const generateCode = () => {
    if (!layout) return '// No layout selected';
    
    const rootComponent: ChainComponent = {
      id: 'root',
      type: 'organism',
      name: layout.name.replace(/\s/g, '') + 'Organism',
      methods: [],
      children: [],
    };

    // Add all components as children with their sections
    Object.entries(components).forEach(([section, comps]) => {
      comps.forEach(comp => {
        rootComponent.children.push({
          ...comp,
          structuralSection: section as StructuralSection,
        });
      });
    });

    return generateFluentChainCode(rootComponent);
  };

  const generatedCode = generateCode();

  // Find template for selected component
  const allTemplates = [...ORGANISMS, ...MOLECULES, ...ATOMS];
  const selectedTemplate = selectedComponent 
    ? allTemplates.find(t => t.name === selectedComponent.name)
    : null;

  const handleSelectComponent = (component: ChainComponent) => {
    setSelectedComponentId(component.id);
    setPropertiesOpen(true);
  };

  const countTotalComponents = () => {
    return Object.values(components).reduce((sum, comps) => sum + comps.length, 0);
  };

  if (!layout) {
    return (
      <div className="h-full flex flex-col">
        {/* Design Surface - Empty State */}
        <div className="h-1/2 relative overflow-hidden border-b border-border">
          {/* Grid Background */}
          <div 
            className="absolute inset-0 opacity-20"
            style={{
              backgroundImage: `
                linear-gradient(to right, var(--color-border) 1px, transparent 1px),
                linear-gradient(to bottom, var(--color-border) 1px, transparent 1px)
              `,
              backgroundSize: '24px 24px',
            }}
          />
          
          {/* Empty State */}
          <div className="relative h-full flex items-center justify-center">
            <div className="text-center max-w-md">
              <h2 className="mb-2">Design Surface</h2>
              <p className="text-muted-foreground">
                Start by selecting an organism layout from the Component Library
              </p>
            </div>
          </div>
        </div>

        {/* Live Preview - Empty State */}
        <div className="h-1/2 relative overflow-hidden">
          <div className="border-b border-border bg-card/80 backdrop-blur-sm px-4 py-2">
            <div className="flex items-center gap-2">
              <Eye className="h-4 w-4" />
              <h3 className="m-0">Live Preview</h3>
            </div>
          </div>
          <div className="h-[calc(100%-49px)] flex items-center justify-center bg-muted/20">
            <p className="text-muted-foreground">Preview will appear here</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Design Surface - Top Half */}
      <div className="h-1/2 relative overflow-hidden border-b border-border flex flex-col">
        {/* Grid Background */}
        <div 
          className="absolute inset-0 opacity-10 pointer-events-none"
          style={{
            backgroundImage: `
              linear-gradient(to right, var(--color-border) 1px, transparent 1px),
              linear-gradient(to bottom, var(--color-border) 1px, transparent 1px)
            `,
            backgroundSize: '24px 24px',
          }}
        />

        {/* Toolbar */}
        <div className="relative z-10 border-b border-border bg-card/80 backdrop-blur-sm px-4 py-2 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="m-0">Design Surface</h3>
            <Badge variant="outline">{layout.name}</Badge>
            <span className="text-sm text-muted-foreground">
              {countTotalComponents()} components
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => setCodeOpen(true)}
            >
              <Code className="h-4 w-4 mr-2" />
              View Code
            </Button>
          </div>
        </div>

        {/* Visual Canvas */}
        <div className="flex-1 relative overflow-auto">
          <VisualDesignCanvas
            layout={layout}
            components={components}
            onDropComponent={onDropComponent}
            onRemoveComponent={onRemoveComponent}
            onSelectComponent={handleSelectComponent}
            selectedComponentId={selectedComponentId}
          />
        </div>
      </div>

      {/* Live Preview - Bottom Half */}
      <div className="h-1/2 flex flex-col">
        <div className="border-b border-border bg-card/80 backdrop-blur-sm px-4 py-2 flex items-center gap-2">
          <Eye className="h-4 w-4" />
          <h3 className="m-0">Live Preview</h3>
        </div>
        <div className="flex-1 overflow-hidden">
          <LivePreview rootComponent={null} />
        </div>
      </div>

      {/* Properties Sheet */}
      <Sheet open={propertiesOpen} onOpenChange={setPropertiesOpen}>
        <SheetContent side="right" className="w-96">
          <SheetHeader>
            <SheetTitle>Properties</SheetTitle>
            <SheetDescription>
              Configure component methods and values
            </SheetDescription>
          </SheetHeader>
          
          {selectedComponent && selectedTemplate && (
            <div className="mt-6 space-y-6">
              {/* Component Info */}
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span>{selectedComponent.name}</span>
                  <Badge variant="outline" className={getComponentColor(selectedComponent.type)}>
                    {selectedComponent.type}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  {selectedTemplate.description}
                </p>
              </div>

              {/* Active Methods */}
              {selectedComponent.methods.length > 0 && (
                <div>
                  <h4 className="mb-3">Active Methods</h4>
                  <div className="space-y-3">
                    {selectedComponent.methods.map(method => {
                      const methodTemplate = selectedTemplate.availableMethods.find(m => m.name === method.name);
                      
                      return (
                        <div key={method.id} className="rounded-lg border border-border p-3 bg-background">
                          <div className="flex items-center justify-between mb-2">
                            <Label className="text-sm">
                              .{method.name}()
                            </Label>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => onRemoveMethod(selectedComponent.id, method.id)}
                              className="h-6 w-6 p-0 text-destructive hover:text-destructive"
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </div>
                          
                          {methodTemplate?.valueType === 'string' && (
                            <Input
                              value={method.value as string || ''}
                              onChange={(e) => onUpdateMethod(selectedComponent.id, method.id, e.target.value)}
                              placeholder={methodTemplate.placeholder || 'Enter value'}
                              className="text-sm"
                            />
                          )}
                          
                          {methodTemplate?.valueType === 'number' && (
                            <Input
                              type="number"
                              value={method.value as number || ''}
                              onChange={(e) => onUpdateMethod(selectedComponent.id, method.id, e.target.value)}
                              placeholder={methodTemplate.placeholder || '0'}
                              className="text-sm"
                            />
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Available Methods */}
              <div>
                <h4 className="mb-3">Available Methods</h4>
                <div className="space-y-2">
                  {selectedTemplate.availableMethods
                    .filter(methodTemplate => 
                      !selectedComponent.methods.some(m => m.name === methodTemplate.name)
                    )
                    .map(methodTemplate => (
                      <Button
                        key={methodTemplate.name}
                        variant="outline"
                        size="sm"
                        onClick={() => onAddMethod(selectedComponent.id, methodTemplate.name)}
                        className="w-full justify-start text-xs"
                      >
                        + .{methodTemplate.name}()
                      </Button>
                    ))}
                </div>
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>

      {/* Code Sheet */}
      <Sheet open={codeOpen} onOpenChange={setCodeOpen}>
        <SheetContent side="right" className="w-[600px]">
          <SheetHeader>
            <SheetTitle>Generated Code</SheetTitle>
            <SheetDescription>
              Copy this fluent chain code to use in your application
            </SheetDescription>
          </SheetHeader>
          
          <ScrollArea className="h-[calc(100vh-120px)] mt-6">
            <pre className="p-4 rounded-lg bg-muted text-sm font-mono">
              <code>{generatedCode}</code>
            </pre>
          </ScrollArea>
        </SheetContent>
      </Sheet>
    </div>
  );
}

function getComponentColor(type: string) {
  switch (type) {
    case 'organism':
      return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
    case 'molecule':
      return 'bg-purple-500/10 text-purple-600 border-purple-500/20';
    case 'atom':
      return 'bg-green-500/10 text-green-600 border-green-500/20';
    default:
      return 'bg-muted text-muted-foreground';
  }
}
