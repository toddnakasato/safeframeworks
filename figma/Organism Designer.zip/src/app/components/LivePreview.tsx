import { ChainComponent } from '../types/fluent-chain';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { 
  TrendingUp, 
  User, 
  Search, 
  BarChart3, 
  Filter,
  Calendar,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

interface LivePreviewProps {
  rootComponent: ChainComponent | null;
}

export function LivePreview({ rootComponent }: LivePreviewProps) {
  if (!rootComponent) {
    return (
      <div className="h-full flex items-center justify-center bg-muted/20">
        <div className="text-center max-w-md">
          <p className="text-muted-foreground">
            No preview available. Add components to see the live preview.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full overflow-auto bg-muted/20 p-8">
      <div className="max-w-6xl mx-auto">
        <ComponentPreview component={rootComponent} />
      </div>
    </div>
  );
}

function ComponentPreview({ component }: { component: ChainComponent }) {
  // Get method values
  const getMethodValue = (name: string) => {
    return component.methods.find(m => m.name === name)?.value || '';
  };

  const hasMethod = (name: string) => {
    return component.methods.some(m => m.name === name);
  };

  // Render based on component type
  switch (component.name) {
    case 'DashboardOrganism':
    case 'FormOrganism':
    case 'ListViewOrganism':
    case 'ModalOrganism':
      return <OrganismPreview component={component} />;
    
    case 'HeaderMolecule':
      return (
        <div className="bg-card border-b border-border p-4 rounded-t-lg">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 flex-1">
              <h2 className="m-0">{getMethodValue('withTitle') || 'Header Title'}</h2>
              {hasMethod('withSearchBar') && (
                <div className="flex-1 max-w-md">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input placeholder="Search..." className="pl-9" />
                  </div>
                </div>
              )}
            </div>
            {hasMethod('withUserProfile') && (
              <Button variant="ghost" size="sm">
                <User className="h-4 w-4 mr-2" />
                Profile
              </Button>
            )}
            {component.children.map(child => (
              <ComponentPreview key={child.id} component={child} />
            ))}
          </div>
        </div>
      );

    case 'MetricsGridMolecule':
      return (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {component.children.map(child => (
            <ComponentPreview key={child.id} component={child} />
          ))}
        </div>
      );

    case 'ChartMolecule':
      const chartType = getMethodValue('withType') || 'line';
      const height = getMethodValue('withHeight') || '400px';
      return (
        <Card className="p-6">
          <div 
            className="flex items-center justify-center bg-muted/50 rounded-lg border-2 border-dashed border-border"
            style={{ height }}
          >
            <div className="text-center">
              <BarChart3 className="h-12 w-12 mx-auto mb-2 text-muted-foreground" />
              <p className="text-muted-foreground">
                {chartType} chart
              </p>
              <p className="text-sm text-muted-foreground">
                Data: {getMethodValue('withData') || 'No data source'}
              </p>
            </div>
          </div>
        </Card>
      );

    case 'FiltersMolecule':
      return (
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <Filter className="h-4 w-4" />
            <h4 className="m-0">Filters</h4>
          </div>
          <div className="space-y-3">
            {component.children.map(child => (
              <ComponentPreview key={child.id} component={child} />
            ))}
          </div>
        </Card>
      );

    case 'SectionMolecule':
      return (
        <Card className="p-6">
          <h3 className="mb-4">{getMethodValue('withTitle') || 'Section'}</h3>
          <div className="space-y-4">
            {component.children.map(child => (
              <ComponentPreview key={child.id} component={child} />
            ))}
          </div>
        </Card>
      );

    case 'DataTableMolecule':
      return (
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted/50 border-b border-border">
                <tr>
                  {component.children.map(child => {
                    const label = child.methods.find(m => m.name === 'withLabel')?.value || 'Column';
                    return (
                      <th key={child.id} className="text-left p-3">
                        {label}
                      </th>
                    );
                  })}
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-border">
                  {component.children.map(child => (
                    <td key={child.id} className="p-3 text-muted-foreground">
                      Sample data
                    </td>
                  ))}
                </tr>
                <tr className="border-b border-border">
                  {component.children.map(child => (
                    <td key={child.id} className="p-3 text-muted-foreground">
                      Sample data
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
          {hasMethod('withPagination') && (
            <div className="p-3 border-t border-border flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                Showing 1-{getMethodValue('withPagination')} of {getMethodValue('withPagination')}
              </p>
              <div className="flex gap-2">
                <Button size="sm" variant="outline">
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button size="sm" variant="outline">
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </Card>
      );

    case 'ButtonGroupMolecule':
      return (
        <div className="flex items-center gap-2">
          {component.children.map(child => (
            <ComponentPreview key={child.id} component={child} />
          ))}
        </div>
      );

    case 'ButtonAtom':
      const variant = getMethodValue('withVariant') || 'default';
      const label = getMethodValue('withLabel') || 'Button';
      return (
        <Button 
          variant={variant as any}
          disabled={hasMethod('isDisabled')}
        >
          {label}
        </Button>
      );

    case 'InputAtom':
      return (
        <div className="space-y-2">
          <label className="text-sm">
            {getMethodValue('withLabel') || 'Input Field'}
            {hasMethod('isRequired') && <span className="text-destructive ml-1">*</span>}
          </label>
          <Input 
            placeholder={getMethodValue('withPlaceholder') || ''}
            disabled={hasMethod('isDisabled')}
          />
        </div>
      );

    case 'MetricCardAtom':
      return (
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">
                {getMethodValue('withLabel') || 'Metric'}
              </p>
              <p className="m-0">
                {getMethodValue('withValue') || '0'}
              </p>
            </div>
            <div className="p-3 bg-primary/10 rounded-lg">
              <TrendingUp className="h-5 w-5 text-primary" />
            </div>
          </div>
        </Card>
      );

    case 'PicklistAtom':
      return (
        <div className="space-y-2">
          <label className="text-sm">
            {getMethodValue('withLabel') || 'Select'}
            {hasMethod('isRequired') && <span className="text-destructive ml-1">*</span>}
          </label>
          <select className="w-full h-10 px-3 rounded-lg border border-input bg-background">
            <option>Select an option...</option>
          </select>
        </div>
      );

    case 'TextareaAtom':
      return (
        <div className="space-y-2">
          <label className="text-sm">
            {getMethodValue('withLabel') || 'Textarea'}
            {hasMethod('isRequired') && <span className="text-destructive ml-1">*</span>}
          </label>
          <textarea 
            className="w-full min-h-[100px] px-3 py-2 rounded-lg border border-input bg-background"
            placeholder={getMethodValue('withPlaceholder') || ''}
          />
        </div>
      );

    case 'DateRangeAtom':
      return (
        <div className="space-y-2">
          <label className="text-sm">
            {getMethodValue('withLabel') || 'Date Range'}
          </label>
          <div className="flex items-center gap-2">
            <Input type="date" />
            <span className="text-muted-foreground">to</span>
            <Input type="date" />
          </div>
        </div>
      );

    case 'ColumnAtom':
      // Rendered within DataTableMolecule
      return null;

    default:
      return (
        <Card className="p-4">
          <p className="text-sm text-muted-foreground">
            {component.name}
          </p>
        </Card>
      );
  }
}

function OrganismPreview({ component }: { component: ChainComponent }) {
  // Group children by structural section
  const childrenBySection: Record<string, ChainComponent[]> = {};
  component.children.forEach(child => {
    const section = child.structuralSection || 'mainBody';
    if (!childrenBySection[section]) {
      childrenBySection[section] = [];
    }
    childrenBySection[section].push(child);
  });

  const topRow = childrenBySection['topRow'] || [];
  const mainBody = childrenBySection['mainBody'] || [];
  const rightPanel = childrenBySection['rightPanel'] || [];
  const leftPanel = childrenBySection['leftPanel'] || [];
  const bottomRow = childrenBySection['bottomRow'] || [];

  // If no children, show placeholder layout based on organism name
  const hasContent = component.children.length > 0;
  const showTopPlaceholder = !hasContent && (component.name.includes('Top') || component.name.includes('Complete'));
  const showLeftPlaceholder = !hasContent && (component.name.includes('Left') || component.name.includes('Complete'));
  const showRightPlaceholder = !hasContent && (component.name.includes('Right') || component.name.includes('Complete'));
  const showBottomPlaceholder = !hasContent && (component.name.includes('Bottom') || component.name.includes('Complete'));
  const showMainPlaceholder = !hasContent;

  return (
    <div className="bg-card rounded-lg shadow-lg overflow-hidden">
      {/* Top Row */}
      {(topRow.length > 0 || showTopPlaceholder) && (
        <div className={topRow.length > 0 ? "space-y-4" : "border-b border-border p-6 bg-muted/20"}>
          {topRow.length > 0 ? (
            topRow.map(child => (
              <ComponentPreview key={child.id} component={child} />
            ))
          ) : (
            <div className="text-center text-muted-foreground text-sm">
              .topRow() - Add header components
            </div>
          )}
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex">
        {/* Left Panel */}
        {(leftPanel.length > 0 || showLeftPlaceholder) && (
          <div className={leftPanel.length > 0 ? "w-64 space-y-4 p-6 border-r border-border" : "w-64 p-6 border-r border-border bg-muted/20"}>
            {leftPanel.length > 0 ? (
              leftPanel.map(child => (
                <ComponentPreview key={child.id} component={child} />
              ))
            ) : (
              <div className="text-center text-muted-foreground text-sm">
                .leftPanel() - Add sidebar
              </div>
            )}
          </div>
        )}

        {/* Main Body */}
        {(mainBody.length > 0 || showMainPlaceholder) && (
          <div className={mainBody.length > 0 ? "flex-1 space-y-6 p-6" : "flex-1 p-6 bg-muted/10"}>
            {mainBody.length > 0 ? (
              mainBody.map(child => (
                <ComponentPreview key={child.id} component={child} />
              ))
            ) : (
              <div className="text-center text-muted-foreground text-sm">
                .mainBody() - Add main content
              </div>
            )}
          </div>
        )}

        {/* Right Panel */}
        {(rightPanel.length > 0 || showRightPlaceholder) && (
          <div className={rightPanel.length > 0 ? "w-80 space-y-4 p-6 border-l border-border" : "w-80 p-6 border-l border-border bg-muted/20"}>
            {rightPanel.length > 0 ? (
              rightPanel.map(child => (
                <ComponentPreview key={child.id} component={child} />
              ))
            ) : (
              <div className="text-center text-muted-foreground text-sm">
                .rightPanel() - Add sidebar
              </div>
            )}
          </div>
        )}
      </div>

      {/* Bottom Row */}
      {(bottomRow.length > 0 || showBottomPlaceholder) && (
        <div className={bottomRow.length > 0 ? "border-t border-border p-6 space-y-4" : "border-t border-border p-6 bg-muted/20"}>
          {bottomRow.length > 0 ? (
            bottomRow.map(child => (
              <ComponentPreview key={child.id} component={child} />
            ))
          ) : (
            <div className="text-center text-muted-foreground text-sm">
              .bottomRow() - Add footer content
            </div>
          )}
        </div>
      )}
    </div>
  );
}
