import { useDrag } from 'react-dnd';
import { ComponentTemplate } from '../types/fluent-chain';
import { Badge } from './ui/badge';

interface DraggableComponentProps {
  template: ComponentTemplate;
  children: React.ReactNode;
}

export function DraggableComponent({ template, children }: DraggableComponentProps) {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: template.type,
    item: template,
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  }));

  return (
    <div
      ref={drag}
      className={`
        group rounded-lg border border-border bg-card p-3 hover:bg-accent/50 cursor-grab transition-all
        ${isDragging ? 'opacity-50 scale-95' : 'opacity-100 scale-100'}
      `}
    >
      {children}
    </div>
  );
}
