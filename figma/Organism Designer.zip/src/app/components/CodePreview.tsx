import { Button } from './ui/button';
import { Copy, Check } from 'lucide-react';
import { useState } from 'react';
import { ScrollArea } from './ui/scroll-area';

interface CodePreviewProps {
  code: string;
}

export function CodePreview({ code }: CodePreviewProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="h-full flex flex-col border-l border-border bg-card">
      <div className="p-4 border-b border-border flex items-center justify-between">
        <div>
          <h2>Generated Code</h2>
          <p className="text-muted-foreground text-sm mt-1">
            Fluent chain output
          </p>
        </div>
        <Button
          size="sm"
          variant="outline"
          onClick={handleCopy}
          className="gap-2"
        >
          {copied ? (
            <>
              <Check className="h-4 w-4" />
              Copied!
            </>
          ) : (
            <>
              <Copy className="h-4 w-4" />
              Copy
            </>
          )}
        </Button>
      </div>
      
      <ScrollArea className="flex-1">
        <pre className="p-4 text-sm font-mono overflow-x-auto">
          <code className="text-foreground">{code}</code>
        </pre>
      </ScrollArea>
    </div>
  );
}
