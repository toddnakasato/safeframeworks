import { useState } from 'react';
import { ChainComponent, StructuralSection } from '../types/fluent-chain';
import { OrganismLayout } from './OrganismDesigner';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Plus, Trash2 } from 'lucide-react';
import { useDrop } from 'react-dnd';

interface VisualDesignCanvasProps {
  layout: OrganismLayout | null;
  components: Record<StructuralSection, ChainComponent[]>;
  onDropComponent: (section: StructuralSection, component: any) => void;
  onRemoveComponent: (section: StructuralSection, componentId: string) => void;
  onSelectComponent: (component: ChainComponent) => void;
  selectedComponentId: string | null;
}

export function VisualDesignCanvas({
  layout,
  components,
  onDropComponent,
  onRemoveComponent,
  onSelectComponent,
  selectedComponentId,
}: VisualDesignCanvasProps) {
  if (!layout) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-center max-w-md">
          <h3 className="mb-2">No Layout Selected</h3>
          <p className="text-muted-foreground">
            Select an organism layout from the Component Library to start designing
          </p>
        </div>
      </div>
    );
  }

  const hasSection = (section: StructuralSection) => layout.sections.includes(section);
  
  // Calculate width classes based on which panels are present
  const hasLeft = hasSection('leftPanel');
  const hasMain = hasSection('mainBody');
  const hasRight = hasSection('rightPanel');
  
  // Determine width for each section
  const getMainContentClasses = () => {
    if (hasLeft && hasMain && hasRight) {
      // All three: 25%, 50%, 25%
      return {
        left: 'w-1/4',
        main: 'w-1/2',
        right: 'w-1/4',
      };
    } else if (hasLeft && hasMain) {
      // Left + Main: 25%, 75%
      return {
        left: 'w-1/4',
        main: 'w-3/4',
        right: '',
      };
    } else if (hasMain && hasRight) {
      // Main + Right: 75%, 25%
      return {
        left: '',
        main: 'w-3/4',
        right: 'w-1/4',
      };
    } else {
      // Single panel: 100%
      return {
        left: hasLeft ? 'w-full' : '',
        main: hasMain ? 'w-full' : '',
        right: hasRight ? 'w-full' : '',
      };
    }
  };
  
  const widthClasses = getMainContentClasses();

  return (
    <div className="h-full p-8 flex items-center justify-center">
      <div className="w-full max-w-6xl h-full max-h-[800px] flex flex-col rounded-lg overflow-hidden shadow-2xl border-2 border-border">
        {/* Top Row */}
        {hasSection('topRow') && (
          <DropZone
            section="topRow"
            components={components.topRow || []}
            onDrop={onDropComponent}
            onRemove={onRemoveComponent}
            onSelect={onSelectComponent}
            selectedId={selectedComponentId}
            className="h-24 border-b-2 border-border"
          />
        )}

        {/* Main Content Area */}
        <div className="flex-1 flex min-h-0">
          {/* Left Panel */}
          {hasSection('leftPanel') && (
            <DropZone
              section="leftPanel"
              components={components.leftPanel || []}
              onDrop={onDropComponent}
              onRemove={onRemoveComponent}
              onSelect={onSelectComponent}
              selectedId={selectedComponentId}
              className={`${widthClasses.left} border-r-2 border-border`}
            />
          )}

          {/* Main Body */}
          {hasSection('mainBody') && (
            <DropZone
              section="mainBody"
              components={components.mainBody || []}
              onDrop={onDropComponent}
              onRemove={onRemoveComponent}
              onSelect={onSelectComponent}
              selectedId={selectedComponentId}
              className={widthClasses.main}
            />
          )}

          {/* Right Panel */}
          {hasSection('rightPanel') && (
            <DropZone
              section="rightPanel"
              components={components.rightPanel || []}
              onDrop={onDropComponent}
              onRemove={onRemoveComponent}
              onSelect={onSelectComponent}
              selectedId={selectedComponentId}
              className={`${widthClasses.right} border-l-2 border-border`}
            />
          )}
        </div>

        {/* Bottom Row */}
        {hasSection('bottomRow') && (
          <DropZone
            section="bottomRow"
            components={components.bottomRow || []}
            onDrop={onDropComponent}
            onRemove={onRemoveComponent}
            onSelect={onSelectComponent}
            selectedId={selectedComponentId}
            className="h-20 border-t-2 border-border"
          />
        )}
      </div>
    </div>
  );
}

interface DropZoneProps {
  section: StructuralSection;
  components: ChainComponent[];
  onDrop: (section: StructuralSection, component: any) => void;
  onRemove: (section: StructuralSection, componentId: string) => void;
  onSelect: (component: ChainComponent) => void;
  selectedId: string | null;
  className?: string;
}

function DropZone({
  section,
  components,
  onDrop,
  onRemove,
  onSelect,
  selectedId,
  className,
}: DropZoneProps) {
  const [{ isOver, canDrop }, drop] = useDrop(() => ({
    accept: ['molecule', 'atom'],
    drop: (item: any) => {
      onDrop(section, item);
    },
    collect: (monitor) => ({
      isOver: monitor.isOver(),
      canDrop: monitor.canDrop(),
    }),
  }));

  const sectionLabels: Record<StructuralSection, string> = {
    topRow: 'Top Row',
    mainBody: 'Main Body',
    leftPanel: 'Left Panel',
    rightPanel: 'Right Panel',
    bottomRow: 'Bottom Row',
  };

  return (
    <div
      ref={drop}
      className={`
        relative p-4 transition-colors
        ${className || ''}
        ${isOver && canDrop ? 'bg-primary/10 ring-2 ring-primary ring-inset' : 'bg-card'}
        ${canDrop ? 'bg-accent/30' : ''}
      `}
    >
      {/* Section Label */}
      <div className="absolute top-2 left-2 z-10">
        <Badge variant="secondary" className="text-xs">
          {sectionLabels[section]}
        </Badge>
      </div>

      {/* Empty State */}
      {components.length === 0 && (
        <div className="h-full flex items-center justify-center border-2 border-dashed border-border rounded-lg">
          <div className="text-center">
            <Plus className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">
              Drag components here
            </p>
          </div>
        </div>
      )}

      {/* Components */}
      {components.length > 0 && (
        <div className="h-full overflow-auto space-y-2 pt-6">
          {components.map((component) => (
            <div
              key={component.id}
              onClick={() => onSelect(component)}
              className={`
                group p-3 rounded-lg border-2 cursor-pointer transition-all
                ${selectedId === component.id 
                  ? 'border-primary bg-primary/5 shadow-md' 
                  : 'border-border bg-background hover:border-primary/50 hover:shadow'
                }
              `}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-sm">{component.name}</span>
                  <Badge 
                    variant="outline" 
                    className={`text-xs ${
                      component.type === 'molecule' 
                        ? 'bg-purple-500/10 text-purple-600 border-purple-500/20'
                        : 'bg-green-500/10 text-green-600 border-green-500/20'
                    }`}
                  >
                    {component.type}
                  </Badge>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={(e) => {
                    e.stopPropagation();
                    onRemove(section, component.id);
                  }}
                  className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Trash2 className="h-3 w-3 text-destructive" />
                </Button>
              </div>
              {component.methods.length > 0 && (
                <div className="mt-1 text-xs text-muted-foreground font-mono">
                  {component.methods.map(m => `.${m.name}()`).join(' ')}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
