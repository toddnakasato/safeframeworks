import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { ComponentTemplate, MOLECULES, ATOMS } from '../types/fluent-chain';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { useState } from 'react';

interface AddComponentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSelectComponent: (template: ComponentTemplate) => void;
}

export function AddComponentDialog({
  open,
  onOpenChange,
  onSelectComponent,
}: AddComponentDialogProps) {
  const [activeTab, setActiveTab] = useState<string>('molecules');

  const renderComponentList = (components: ComponentTemplate[]) => {
    const categories = Array.from(new Set(components.map(c => c.category)));
    
    return (
      <div className="space-y-4">
        {categories.map(category => (
          <div key={category}>
            <h4 className="mb-2 text-muted-foreground">{category}</h4>
            <div className="space-y-2">
              {components
                .filter(c => c.category === category)
                .map(component => (
                  <div
                    key={component.name}
                    className="rounded-lg border border-border bg-card p-3 hover:bg-accent/50 cursor-pointer transition-colors"
                    onClick={() => {
                      onSelectComponent(component);
                      onOpenChange(false);
                    }}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span>{component.name}</span>
                          <Badge variant="secondary" className="text-xs">
                            {component.type}
                          </Badge>
                        </div>
                        <p className="text-muted-foreground mt-1 text-sm">
                          {component.description}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle>Add Component</DialogTitle>
          <DialogDescription>
            Select a molecule or atom to add to your chain
          </DialogDescription>
        </DialogHeader>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="w-full justify-start">
            <TabsTrigger value="molecules">Molecules</TabsTrigger>
            <TabsTrigger value="atoms">Atoms</TabsTrigger>
          </TabsList>
          
          <ScrollArea className="flex-1 mt-4 max-h-[50vh]">
            <TabsContent value="molecules" className="mt-0">
              {renderComponentList(MOLECULES)}
            </TabsContent>
            <TabsContent value="atoms" className="mt-0">
              {renderComponentList(ATOMS)}
            </TabsContent>
          </ScrollArea>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
