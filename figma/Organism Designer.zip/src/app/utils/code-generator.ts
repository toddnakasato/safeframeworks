import { ChainComponent, StructuralSection } from '../types/fluent-chain';

export function generateFluentChainCode(component: ChainComponent | null): string {
  if (!component) {
    return '// Start by adding an organism from the Component Library';
  }

  const lines: string[] = [];
  
  // Generate the component
  generateComponentCode(component, 0, lines);
  
  return lines.join('\n');
}

function generateComponentCode(
  component: ChainComponent,
  indent: number,
  lines: string[],
  isNested: boolean = false
): void {
  const indentStr = '    '.repeat(indent);
  
  // Start the component
  if (indent === 0) {
    lines.push(`${component.name} result = new ${component.name}()`);
  } else {
    lines.push(`${indentStr}${isNested ? '' : '.add'}${isNested ? 'new ' : ''}${component.name}(`);
    if (isNested) {
      lines[lines.length - 1] = lines[lines.length - 1].replace('(', '(new ');
    }
  }
  
  // Add methods
  component.methods.forEach(method => {
    const value = formatMethodValue(method.value);
    lines.push(`${indentStr}    .${method.name}${value}`);
  });
  
  // Handle structural sections for organisms
  if (component.type === 'organism' && component.children.length > 0) {
    // Group children by structural section
    const sectionGroups = groupBySection(component.children);
    
    Object.entries(sectionGroups).forEach(([section, children]) => {
      lines.push(`${indentStr}    .${section}()`);
      
      children.forEach(child => {
        generateChildComponent(child, indent + 2, lines);
      });
    });
  } else if (component.children.length > 0) {
    // For molecules, just add children directly
    component.children.forEach(child => {
      generateChildComponent(child, indent + 1, lines);
    });
  }
  
  // Close the component
  if (indent === 0) {
    lines.push(`${indentStr}    .build();`);
  } else {
    lines.push(`${indentStr})`);
  }
}

function generateChildComponent(
  component: ChainComponent,
  indent: number,
  lines: string[]
): void {
  const indentStr = '    '.repeat(indent);
  const addMethod = component.type === 'molecule' ? 'addMolecule' : 
                    component.type === 'atom' ? getAtomAddMethod(component) : 'add';
  
  // Start the child component
  lines.push(`${indentStr}.${addMethod}(new ${component.name}()`);
  
  // Add methods
  component.methods.forEach(method => {
    const value = formatMethodValue(method.value);
    lines.push(`${indentStr}    .${method.name}${value}`);
  });
  
  // Add nested children
  if (component.children.length > 0) {
    component.children.forEach(child => {
      generateNestedChild(child, indent + 1, lines);
    });
  }
  
  // Close the child component
  lines.push(`${indentStr})`);
}

function generateNestedChild(
  component: ChainComponent,
  indent: number,
  lines: string[]
): void {
  const indentStr = '    '.repeat(indent);
  const addMethod = getAtomAddMethod(component);
  
  lines.push(`${indentStr}.${addMethod}(new ${component.name}()`);
  
  component.methods.forEach(method => {
    const value = formatMethodValue(method.value);
    lines.push(`${indentStr}    .${method.name}${value}`);
  });
  
  if (component.children.length > 0) {
    component.children.forEach(child => {
      generateNestedChild(child, indent + 1, lines);
    });
  }
  
  lines.push(`${indentStr})`);
}

function getAtomAddMethod(component: ChainComponent): string {
  // Determine the appropriate add method based on the atom type
  if (component.name.includes('Button')) return 'addButton';
  if (component.name.includes('Field') || component.name.includes('Input')) return 'addField';
  if (component.name.includes('Filter')) return 'addFilter';
  if (component.name.includes('Column')) return 'addColumn';
  if (component.name.includes('MetricCard')) return 'addMetricCard';
  if (component.name.includes('Action')) return 'addAction';
  return 'add';
}

function groupBySection(children: ChainComponent[]): Record<string, ChainComponent[]> {
  const groups: Record<string, ChainComponent[]> = {};
  
  children.forEach(child => {
    const section = child.structuralSection || 'mainBody';
    if (!groups[section]) {
      groups[section] = [];
    }
    groups[section].push(child);
  });
  
  return groups;
}

function formatMethodValue(value: string | boolean | number | undefined): string {
  if (value === undefined || value === '') {
    return '()';
  }
  
  if (typeof value === 'boolean') {
    return '()';
  }
  
  if (typeof value === 'number') {
    return `(${value})`;
  }
  
  return `('${value}')`;
}
