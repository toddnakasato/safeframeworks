// Types for the fluent chain builder

export type ComponentType = 'organism' | 'molecule' | 'atom';

export type StructuralSection = 'topRow' | 'mainBody' | 'leftPanel' | 'rightPanel' | 'bottomRow';

export interface OrganismLayoutConfig {
  sections: StructuralSection[];
  name: string;
}

export interface ChainComponent {
  id: string;
  type: ComponentType;
  name: string;
  methods: ChainMethod[];
  children: ChainComponent[];
  structuralSection?: StructuralSection;
}

export interface ChainMethod {
  id: string;
  name: string;
  value?: string | boolean | number;
  type: 'config' | 'state' | 'add';
}

export interface ComponentTemplate {
  type: ComponentType;
  name: string;
  description: string;
  category: string;
  availableMethods: MethodTemplate[];
  canHaveChildren: boolean;
  structuralSections?: StructuralSection[];
}

export interface MethodTemplate {
  name: string;
  type: 'config' | 'state' | 'add';
  valueType?: 'string' | 'boolean' | 'number' | 'none';
  placeholder?: string;
}

// Component library definitions
export const ORGANISMS: ComponentTemplate[] = [
  {
    type: 'organism',
    name: 'DashboardOrganism',
    description: 'Top-level dashboard layout',
    category: 'Layout',
    canHaveChildren: true,
    structuralSections: ['topRow', 'mainBody', 'rightPanel', 'bottomRow'],
    availableMethods: [
      { name: 'withSize', type: 'config', valueType: 'string', placeholder: 'large' },
      { name: 'withLayout', type: 'config', valueType: 'string', placeholder: 'grid' },
      { name: 'withTheme', type: 'config', valueType: 'string', placeholder: 'light' },
    ],
  },
  {
    type: 'organism',
    name: 'FormOrganism',
    description: 'Form layout structure',
    category: 'Layout',
    canHaveChildren: true,
    structuralSections: ['topRow', 'mainBody', 'rightPanel', 'bottomRow'],
    availableMethods: [
      { name: 'withSize', type: 'config', valueType: 'string', placeholder: 'medium' },
    ],
  },
  {
    type: 'organism',
    name: 'ListViewOrganism',
    description: 'List view layout',
    category: 'Layout',
    canHaveChildren: true,
    structuralSections: ['topRow', 'mainBody', 'bottomRow'],
    availableMethods: [],
  },
  {
    type: 'organism',
    name: 'ModalOrganism',
    description: 'Modal dialog layout',
    category: 'Layout',
    canHaveChildren: true,
    structuralSections: ['topRow', 'mainBody', 'bottomRow'],
    availableMethods: [
      { name: 'withSize', type: 'config', valueType: 'string', placeholder: 'small' },
    ],
  },
];

export const MOLECULES: ComponentTemplate[] = [
  {
    type: 'molecule',
    name: 'HeaderMolecule',
    description: 'Page header with title and actions',
    category: 'Navigation',
    canHaveChildren: true,
    availableMethods: [
      { name: 'withTitle', type: 'config', valueType: 'string', placeholder: 'Page Title' },
      { name: 'withSearchBar', type: 'config', valueType: 'none' },
      { name: 'withUserProfile', type: 'config', valueType: 'none' },
      { name: 'addAction', type: 'add', valueType: 'none' },
    ],
  },
  {
    type: 'molecule',
    name: 'MetricsGridMolecule',
    description: 'Grid of metric cards',
    category: 'Data',
    canHaveChildren: true,
    availableMethods: [
      { name: 'addMetricCard', type: 'add', valueType: 'none' },
    ],
  },
  {
    type: 'molecule',
    name: 'ChartMolecule',
    description: 'Chart component',
    category: 'Data',
    canHaveChildren: false,
    availableMethods: [
      { name: 'withType', type: 'config', valueType: 'string', placeholder: 'line' },
      { name: 'withData', type: 'config', valueType: 'string', placeholder: 'salesData' },
      { name: 'withHeight', type: 'config', valueType: 'string', placeholder: '400px' },
    ],
  },
  {
    type: 'molecule',
    name: 'FiltersMolecule',
    description: 'Filter panel',
    category: 'Controls',
    canHaveChildren: true,
    availableMethods: [
      { name: 'addFilter', type: 'add', valueType: 'none' },
    ],
  },
  {
    type: 'molecule',
    name: 'SectionMolecule',
    description: 'Form section with fields',
    category: 'Form',
    canHaveChildren: true,
    availableMethods: [
      { name: 'withTitle', type: 'config', valueType: 'string', placeholder: 'Section Title' },
      { name: 'addField', type: 'add', valueType: 'none' },
    ],
  },
  {
    type: 'molecule',
    name: 'DataTableMolecule',
    description: 'Data table with columns',
    category: 'Data',
    canHaveChildren: true,
    availableMethods: [
      { name: 'addColumn', type: 'add', valueType: 'none' },
      { name: 'withData', type: 'config', valueType: 'string', placeholder: 'dataSource' },
      { name: 'withPagination', type: 'config', valueType: 'number', placeholder: '50' },
    ],
  },
  {
    type: 'molecule',
    name: 'ButtonGroupMolecule',
    description: 'Group of buttons',
    category: 'Controls',
    canHaveChildren: true,
    availableMethods: [
      { name: 'addButton', type: 'add', valueType: 'none' },
    ],
  },
];

export const ATOMS: ComponentTemplate[] = [
  {
    type: 'atom',
    name: 'ButtonAtom',
    description: 'Basic button',
    category: 'Controls',
    canHaveChildren: false,
    availableMethods: [
      { name: 'withLabel', type: 'config', valueType: 'string', placeholder: 'Click Me' },
      { name: 'withIcon', type: 'config', valueType: 'string', placeholder: 'add' },
      { name: 'withVariant', type: 'config', valueType: 'string', placeholder: 'primary' },
      { name: 'isDisabled', type: 'state', valueType: 'none' },
    ],
  },
  {
    type: 'atom',
    name: 'InputAtom',
    description: 'Text input field',
    category: 'Form',
    canHaveChildren: false,
    availableMethods: [
      { name: 'withLabel', type: 'config', valueType: 'string', placeholder: 'Field Label' },
      { name: 'withPlaceholder', type: 'config', valueType: 'string', placeholder: 'Enter value...' },
      { name: 'isRequired', type: 'state', valueType: 'none' },
      { name: 'isDisabled', type: 'state', valueType: 'none' },
    ],
  },
  {
    type: 'atom',
    name: 'MetricCardAtom',
    description: 'Metric display card',
    category: 'Data',
    canHaveChildren: false,
    availableMethods: [
      { name: 'withLabel', type: 'config', valueType: 'string', placeholder: 'Metric Name' },
      { name: 'withValue', type: 'config', valueType: 'string', placeholder: '100' },
      { name: 'withIcon', type: 'config', valueType: 'string', placeholder: 'trending-up' },
    ],
  },
  {
    type: 'atom',
    name: 'PicklistAtom',
    description: 'Dropdown select',
    category: 'Form',
    canHaveChildren: false,
    availableMethods: [
      { name: 'withLabel', type: 'config', valueType: 'string', placeholder: 'Select Option' },
      { name: 'withOptions', type: 'config', valueType: 'string', placeholder: 'options' },
      { name: 'isRequired', type: 'state', valueType: 'none' },
    ],
  },
  {
    type: 'atom',
    name: 'TextareaAtom',
    description: 'Multi-line text input',
    category: 'Form',
    canHaveChildren: false,
    availableMethods: [
      { name: 'withLabel', type: 'config', valueType: 'string', placeholder: 'Description' },
      { name: 'withPlaceholder', type: 'config', valueType: 'string', placeholder: 'Enter text...' },
      { name: 'isRequired', type: 'state', valueType: 'none' },
    ],
  },
  {
    type: 'atom',
    name: 'ColumnAtom',
    description: 'Table column definition',
    category: 'Data',
    canHaveChildren: false,
    availableMethods: [
      { name: 'withField', type: 'config', valueType: 'string', placeholder: 'fieldName' },
      { name: 'withLabel', type: 'config', valueType: 'string', placeholder: 'Column Header' },
      { name: 'withType', type: 'config', valueType: 'string', placeholder: 'text' },
      { name: 'isSortable', type: 'state', valueType: 'none' },
    ],
  },
  {
    type: 'atom',
    name: 'DateRangeAtom',
    description: 'Date range picker',
    category: 'Form',
    canHaveChildren: false,
    availableMethods: [
      { name: 'withLabel', type: 'config', valueType: 'string', placeholder: 'Date Range' },
    ],
  },
];
